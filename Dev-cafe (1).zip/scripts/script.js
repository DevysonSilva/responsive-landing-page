document.querySelector('.menu-btn').addEventListener('click', function () {
  document.querySelector('.navbar').classList.toggle('active');
});